package com.elitecity.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private static final String SERVER = "elite-rp.servegame.com:7008";
    private static final String DISCORD = "https://discord.gg/FFJQu8UG";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7, 17, 34));
        getWindow().setNavigationBarColor(Color.rgb(7, 17, 34));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER);
        page.setPadding(28, 32, 28, 32);
        page.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(5, 17, 39), Color.rgb(0, 91, 130), Color.rgb(4, 13, 29)}));

        TextView flag = new TextView(this);
        flag.setText("🇹🇳");
        flag.setTextSize(42);
        flag.setGravity(Gravity.CENTER);
        page.addView(flag);

        TextView title = new TextView(this);
        title.setText("ELITE CITY");
        title.setTextColor(Color.WHITE);
        title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("TUNISIAN ROLEPLAY");
        subtitle.setTextColor(Color.rgb(160, 220, 245));
        subtitle.setTextSize(13);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 4, 0, 28);
        page.addView(subtitle);

        TextView server = new TextView(this);
        server.setText("SERVER\n" + SERVER);
        server.setTextColor(Color.WHITE);
        server.setTextSize(17);
        server.setGravity(Gravity.CENTER);
        server.setPadding(18, 18, 18, 18);
        server.setBackground(round(Color.argb(70, 255, 255, 255), 18));
        page.addView(server, new LinearLayout.LayoutParams(-1, -2));

        Button play = button("PLAY  •  OPEN SA-MP MOBILE", true);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 58);
        bp.setMargins(0, 28, 0, 12);
        page.addView(play, bp);
        play.setOnClickListener(v -> openSamp());

        Button copy = button("COPY SERVER IP", false);
        page.addView(copy, new LinearLayout.LayoutParams(-1, 54));
        copy.setOnClickListener(v -> {
            android.content.ClipboardManager cm = (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("ELITE CITY IP", SERVER));
            Toast.makeText(this, "Server IP copied", Toast.LENGTH_SHORT).show();
        });

        Button discord = button("JOIN DISCORD", false);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, 54);
        dp.setMargins(0, 12, 0, 0);
        page.addView(discord, dp);
        discord.setOnClickListener(v -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(DISCORD))); }
            catch (Exception e) { Toast.makeText(this, "Cannot open Discord link", Toast.LENGTH_SHORT).show(); }
        });

        TextView footer = new TextView(this);
        footer.setText("WELCOME TO ELITE CITY");
        footer.setTextColor(Color.rgb(180, 215, 230));
        footer.setTextSize(11);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.setMargins(0, 34, 0, 0);
        page.addView(footer, fp);

        setContentView(page);
    }

    private void openSamp() {
        PackageManager pm = getPackageManager();
        try {
            for (ApplicationInfo app : pm.getInstalledApplications(PackageManager.GET_META_DATA)) {
                String label = pm.getApplicationLabel(app).toString().toLowerCase();
                if (label.contains("samp") || label.contains("sa-mp")) {
                    Intent launch = pm.getLaunchIntentForPackage(app.packageName);
                    if (launch != null) { startActivity(launch); return; }
                }
            }
        } catch (Exception ignored) {}
        Toast.makeText(this, "Install SA-MP Mobile first, then try again.", Toast.LENGTH_LONG).show();
    }

    private Button button(String text, boolean primary) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackground(round(primary ? Color.rgb(0, 145, 190) : Color.rgb(22, 48, 72), 16));
        return b;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(1, Color.argb(65, 255, 255, 255));
        return d;
    }
}
