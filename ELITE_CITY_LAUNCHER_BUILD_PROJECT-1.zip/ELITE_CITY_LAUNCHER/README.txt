ELITE CITY Android launcher source project

Includes:
- ELITE CITY branding and Tunisian flag
- Server IP: elite-rp.servegame.com:7008
- Copy server IP button
- Discord invite button
- PLAY button searches installed apps for a launcher whose app name contains SA-MP / samp

IMPORTANT:
This ZIP is an Android Studio source project, NOT an APK.
To build: open this folder in Android Studio and build the debug APK,
or push it to a GitHub repository and run the workflow:
Actions -> Build ELITE CITY APK -> Run workflow.
The APK is uploaded as an artifact named ELITE-CITY-APK.

The PLAY button opens SA-MP Mobile if Android exposes its installed app
name with "SA-MP" or "samp". It does not automatically join the server;
the server IP can be copied from the launcher.
